import numpy as np
import matplotlib.pyplot as plt

vds_list = [0.05, 1.1]
names = ['Nominal', 'UA = UB = 0', 'VSAT x 100']
files = ['Q_4.txt', 'Q_4_equal.txt', 'Q_4_vsat.txt']
colors = ['blue', 'orange', 'green']

fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))

for f in range(3):
    # ---------- Read one file ----------
    raw = open('../data/' + files[f], 'rb').read()
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        text = raw.decode('utf-16')
    else:
        text = raw.decode('latin-1')

    data = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('Step Information'):
            data.append([])
            continue
        try:
            vg, i_d = line.split()
            data[-1].append([float(vg), float(i_d)])
        except (ValueError, IndexError):
            pass

    # ---------- Plot both VDS sweeps ----------
    for i in range(2):
        d = np.array(data[i])
        if i == 0:
            style = '--'
        else:
            style = '-'
        label = f'{names[f]}, VDS = {vds_list[i]} V'

        ax[0].plot(d[:, 0], d[:, 1] * 1e6, style, color=colors[f], label=label)
        ax[1].semilogy(d[:, 0], d[:, 1], style, color=colors[f], label=label)

        print(names[f], 'VDS =', vds_list[i], 'V: Id(1.1 V) =', round(d[-1, 1] * 1e3, 3), 'mA')

ax[0].set_title('Linear')
ax[1].set_title('Log')
ax[0].set_xlabel('VGS (V)')
ax[0].set_ylabel('ID (uA/um)')
ax[1].set_xlabel('VGS (V)')
ax[1].set_ylabel('ID (A/um)')
for a in ax:
    a.grid(True)
    a.legend(fontsize=7)

plt.tight_layout()
plt.savefig('../figures/s4.png', dpi=300)
plt.show()
