import numpy as np
import matplotlib.pyplot as plt

# ---------- Read data ----------
raw = open('../data/Q_3.txt', 'rb').read()
if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
    text = raw.decode('utf-16')
else:
    text = raw.decode('latin-1')

# data[0] = first VGS sweep, data[1] = second, ...
vgs_list = [0.3, 0.6, 0.9, 1.5]
data = []

for line in text.splitlines():
    line = line.strip()
    if line.startswith('Step Information'):
        data.append([])                  # start a new sweep
        continue
    try:
        vd, i_d = line.split()
        data[-1].append([float(vd), float(i_d)])
    except (ValueError, IndexError):
        pass                             # skip headers and blank lines

# ---------- ID vs VDS plot ----------
plt.figure(figsize=(10, 6))
for i in range(4):
    d = np.array(data[i])
    plt.plot(d[:, 0], d[:, 1] * 1e3, label=f'VGS = {vgs_list[i]} V')
plt.title('Output characteristics (ID vs VDS)')
plt.xlabel('VDS (V)')
plt.ylabel('ID (mA/um)')
plt.legend()
plt.grid(True)
plt.savefig('../figures/s3_idvd.png', dpi=300)

# ---------- gds plot and ro ----------
plt.figure(figsize=(10, 6))
for i in range(4):
    d = np.array(data[i])
    v_ds = d[:, 0]
    i_d = d[:, 1]

    gds = np.gradient(i_d, v_ds)                # output conductance
    ro = np.interp(1.0, v_ds, 1 / gds) / 1e3    # output resistance at VDS = 1 V

    print('VGS =', vgs_list[i], 'V:  ro (VDS = 1.0 V) =', round(ro, 2), 'kOhm.um')
    plt.plot(v_ds, gds * 1e3, '--', label=f'VGS = {vgs_list[i]} V')

plt.title('Output conductance gds = dID/dVDS')
plt.xlabel('VDS (V)')
plt.ylabel('gds (mS/um)')
plt.legend()
plt.grid(True)
plt.savefig('../figures/s3_gds.png', dpi=300)

plt.show()
