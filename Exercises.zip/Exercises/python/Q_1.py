xl = -30e-9
lint = 5.25e-9
wint = 5e-9
toxe = 1.85e-9
eps0 = 8.854e-12
epsrox = 3.9

cox = epsrox * eps0 / toxe          # F/m^2

for l in (65e-9, 70e-9):
    leff = l + xl - 2 * lint
    print("L =", l * 1e9, "nm -> Leff =", leff * 1e9, "nm")

weff = 1e-6 - 2 * wint
print("Weff =", weff * 1e9, "nm")
print("Cox  =", cox, "F/m^2 =", cox * 1e3, "fF/um^2")

id65 = 1.15229e-3
id70 = 1.04856e-3
print("Id drop       =", 100 * (id65 - id70) / id65, "%")
print("Leff increase =", 100 * (29.5 - 24.5) / 24.5, "%")
