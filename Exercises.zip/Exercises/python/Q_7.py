import numpy as np
import matplotlib.pyplot as plt

# ---------- Read data (three columns: Vin, Vout, supply current) ----------
raw = open('../data/Q_7.txt', 'rb').read()
if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
    text = raw.decode('utf-16')
else:
    text = raw.decode('latin-1')

rows = []
for line in text.splitlines():
    try:
        a, b, c = line.split()
        rows.append([float(a), float(b), float(c)])
    except ValueError:
        pass                              # skip header and blank lines

d = np.array(rows)
print(d.shape)                            # expect (1101, 3)

vin = d[:, 0]
vout = d[:, 1]
idd = d[:, 2]

# supply current should peak positive; flip the sign if needed
if abs(idd.min()) > abs(idd.max()):
    idd = -idd

# ---------- Key numbers ----------
gain = np.gradient(vout, vin)             # dVout/dVin
k = np.argmin(gain)                       # steepest (most negative) point
diff = vout - vin
vm = np.interp(0.0, diff[::-1], vin[::-1])    # Vout = Vin (reversed because diff falls with Vin)
kp = np.argmax(idd)

print('Vout at Vin = 0    :', round(vout[0], 4), 'V')
print('Vout at Vin = VDD  :', round(vout[-1], 4), 'V')
print('Vm (Vout = Vin)    :', round(vm, 3), 'V')
print('Max |gain|         :', round(abs(gain[k]), 1), 'at Vin =', round(vin[k], 3), 'V')
print('Peak supply current:', round(idd[kp] * 1e6, 2), 'uA at Vin =', round(vin[kp], 3), 'V')
print('Idd at Vin = 0     :', idd[0], 'A')
print('Idd at Vin = VDD   :', idd[-1], 'A')

# ---------- Figure 1: transfer characteristic ----------
plt.figure(figsize=(8, 6))
plt.plot(vin, vout, label='VOUT')
plt.plot([0, 1.1], [0, 1.1], '--', color='gray', label='VOUT = VIN')
plt.plot(vm, vm, 'ro', label='VM = ' + str(round(vm, 3)) + ' V')
plt.title('CMOS inverter transfer characteristic')
plt.xlabel('VIN (V)')
plt.ylabel('VOUT (V)')
plt.legend()
plt.grid(True)
plt.savefig('../figures/s7_vtc.png', dpi=300)

# ---------- Figure 2: gain with the peak marked ----------
plt.figure(figsize=(8, 6))
plt.plot(vin, gain, label='Gain dVOUT/dVIN')
plt.plot(vin[k], gain[k], 'ro', label='Peak gain = ' + str(round(gain[k], 2)) + ' at VIN = ' + str(round(vin[k], 3)) + ' V')
plt.axvline(vm, color='gray', linestyle='--', label='VM = ' + str(round(vm, 3)) + ' V')
plt.axhline(-1, color='green', linestyle=':', label='|gain| = 1')
plt.title('Inverter gain dVOUT/dVIN')
plt.xlabel('VIN (V)')
plt.ylabel('Gain (V/V)')
plt.legend(loc='lower left', fontsize=9)
plt.grid(True)
plt.savefig('../figures/s7_gain.png', dpi=300)

plt.show()
