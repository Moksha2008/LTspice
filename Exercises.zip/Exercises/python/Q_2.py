import numpy as np
import matplotlib.pyplot as plt

# ---------- Read data ----------
raw = open('../data/Q_2.txt', 'rb').read()
if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
    text = raw.decode('utf-16')
else:
    text = raw.decode('latin-1')

# data[0] = first VDS sweep, data[1] = second VDS sweep
vds_list = [0.05, 1.1]
data = []

for line in text.splitlines():
    if line.startswith('Step Information'):
        data.append([])                  # start a new sweep
        continue
    try:
        vg, i_d = line.split()
        data[-1].append([float(vg), float(i_d)])
    except (ValueError, IndexError):
        pass                             # skip headers and blank lines

# ---------- Linear plot ----------
plt.figure(figsize=(10, 6))
for i in range(2):
    d = np.array(data[i])
    plt.plot(d[:, 0], d[:, 1] * 1e6, label=f'VDS = {vds_list[i]} V')
plt.title('Transfer characteristics (linear)')
plt.xlabel('VGS (V)')
plt.ylabel('ID (uA/um)')
plt.legend()
plt.grid(True)
plt.savefig('../figures/s2_linear.png', dpi=300)

# ---------- Log plot ----------
plt.figure(figsize=(10, 6))
for i in range(2):
    d = np.array(data[i])
    plt.semilogy(d[:, 0], d[:, 1], label=f'VDS = {vds_list[i]} V')
plt.title('Transfer characteristics (log)')
plt.xlabel('VGS (V)')
plt.ylabel('ID (A/um)')
plt.legend()
plt.grid(True)
plt.savefig('../figures/s2_log.png', dpi=300)

# ---------- Extract parameters ----------
i_cc = 100e-9 * 1e-6 / 65e-9      # constant current level
vth_cc = []

for i in range(2):
    d = np.array(data[i])
    vg = d[:, 0]
    i_d = d[:, 1]

    # Vth by max gm method
    gm = np.gradient(i_d, vg)
    k = np.argmax(gm)
    vth_lin = vg[k] - i_d[k] / gm[k]

    # Vth by constant current method
    vth = np.interp(i_cc, i_d, vg)
    vth_cc.append(vth)

    # Subthreshold swing
    sub = (i_d > 1e-11) & (vg < vth)
    ss = 1000 * np.min(np.gradient(vg[sub], np.log10(i_d[sub])))

    # Ion and Ioff
    ion = np.interp(1.1, vg, i_d)
    ioff = np.interp(0.0, vg, i_d)

    print('VDS =', vds_list[i])
    print('  Vth_lin =', round(vth_lin, 3), 'V')
    print('  Vth_cc  =', round(vth, 3), 'V')
    print('  SS      =', round(ss, 1), 'mV/dec')
    print('  Ion     =', round(ion * 1e3, 3), 'mA/um')
    print('  Ioff    =', round(ioff * 1e9, 1), 'nA/um')

# DIBL
dibl = (vth_cc[0] - vth_cc[1]) / (1.1 - 0.05) * 1000
print('DIBL =', round(dibl), 'mV/V')

plt.show()
