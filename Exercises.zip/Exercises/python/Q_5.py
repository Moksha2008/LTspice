import numpy as np
import matplotlib.pyplot as plt

# value labels
experiments = {
    1:  ('VTH0',  ['0.30 V', '0.423 V', '0.55 V']),
    2:  ('TOXE',  ['1.5 nm', '1.85 nm', '2.5 nm']),
    3:  ('L',     ['55 nm', '65 nm', '100 nm']),
    4:  ('XL',    ['-35 nm', '-30 nm', '-15 nm']),
    5:  ('LINT',  ['2 nm', '5.25 nm', '8 nm']),
    6:  ('W',     ['0.5 um', '1 um', '2 um']),
    7:  ('WINT',  ['0 nm', '5 nm', '40 nm']),
    8:  ('NDEP',  ['1.5e18', '2.54e18', '4e18']),
    9:  ('NSD',   ['5e19', '2e20', '5e20']),
    10: ('XJ',    ['10 nm', '19.6 nm', '30 nm']),
    11: ('NGATE', ['1e19', '2e20', '1e21']),
    12: ('U0',    ['300', '491', '700']),
    13: ('VSAT',  ['0.8e7', '1.24e7', '2e7']),
    14: ('RDSW',  ['50', '165', '400']),
}
colors = ['blue', 'green', 'red']       # low / nominal / high
width_um = [0.5, 1.0, 2.0]             

summary = []


def vth_tangent(v, i):
    gm = np.gradient(i, v)
    k = np.argmax(gm)
    return v[k] - i[k] / gm[k]


def subthreshold_slope(v, i, vth):
    m = (i > 1e-11) & (v < vth)
    if m.sum() < 5:
        return np.nan
    return 1e3 * np.min(np.gradient(v[m], np.log10(i[m])))   # mV/dec


for n in experiments:
    name = experiments[n][0]
    values = experiments[n][1]

    # ---------- Read file ----------
    fname = '../data/Q_5_p' + str(n).zfill(2) + '.txt'
    try:
        raw = open(fname, 'rb').read()
    except FileNotFoundError:
        print('no file yet for experiment', n, name)
        continue
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        text = raw.decode('utf-16')
    else:
        text = raw.decode('latin-1')

    # each run has columns: Vs, Id_vg, Id_vd
    data = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('Step Information'):
            data.append([])
            continue
        try:
            vs, i1, i2 = line.split()
            data[-1].append([float(vs), float(i1), float(i2)])
        except (ValueError, IndexError):
            pass

    print('Experiment', n, name, ':', len(data), 'runs')

    # ---------- Plots and numbers ----------
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.8))
    for run in range(len(data)):
        d = np.array(data[run])
        v = d[:, 0]
        i_g = d[:, 1]
        i_d = d[:, 2]
        label = name + ' = ' + values[run]

        vth = vth_tangent(v, i_g)
        ioff = np.interp(0.0, v, i_g)
        ion_vg = np.interp(1.1, v, i_g)     # VGS = 1.1 V, VDS = 0.4 V
        id_vd = np.interp(1.1, v, i_d)      # VGS = 1.1 V, VDS = 1.1 V
        ss = subthreshold_slope(v, i_g, vth)

        summary.append([n, name, values[run], vth, ss, ioff, ion_vg * 1e3, id_vd * 1e3])
        print('  ' + label)
        print('    Vth_lin =', round(vth, 3), 'V, SS =', round(ss, 1), 'mV/dec, Ioff =', ioff, 'A')
        print('    Id(1.1 V, 0.4 V) =', round(ion_vg * 1e3, 3), 'mA, Id(1.1 V, 1.1 V) =', round(id_vd * 1e3, 3), 'mA')

        ax[0].plot(v, i_g * 1e3, color=colors[run], label=label)
        ax[1].semilogy(v, np.clip(i_g, 1e-15, None), color=colors[run], label=label)
        ax[2].plot(v, i_d * 1e3, color=colors[run], label=label)

    ax[0].set_title('ID-VGS, VDS = 0.4 V (linear)')
    ax[0].set_xlabel('VGS (V)')
    ax[0].set_ylabel('ID (mA)')
    ax[1].set_title('ID-VGS, VDS = 0.4 V (log)')
    ax[1].set_xlabel('VGS (V)')
    ax[1].set_ylabel('ID (A)')
    ax[2].set_title('ID-VDS, VGS = 1.1 V')
    ax[2].set_xlabel('VDS (V)')
    ax[2].set_ylabel('ID (mA)')
    for a in ax:
        a.grid(True)
        a.legend(fontsize=9)
    fig.suptitle('Experiment ' + str(n) + ': variation of ' + name)
    plt.tight_layout()
    plt.savefig('../figures/s5_e' + str(n).zfill(2) + '_' + name + '.png', dpi=300)
    plt.close()

  
    if n == 6:
        fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
        for run in range(len(data)):
            d = np.array(data[run])
            w = width_um[run]
            ax[0].plot(d[:, 0], d[:, 1] * 1e3 / w, color=colors[run], label='W = ' + str(w) + ' um')
            ax[1].plot(d[:, 0], d[:, 2] * 1e3 / w, color=colors[run], label='W = ' + str(w) + ' um')
        ax[0].set_title('ID/W vs VGS, VDS = 0.4 V')
        ax[0].set_xlabel('VGS (V)')
        ax[0].set_ylabel('ID/W (mA/um)')
        ax[1].set_title('ID/W vs VDS, VGS = 1.1 V')
        ax[1].set_xlabel('VDS (V)')
        ax[1].set_ylabel('ID/W (mA/um)')
        for a in ax:
            a.grid(True)
            a.legend()
        plt.tight_layout()
        plt.savefig('../figures/s5_e06_W_per_um.png', dpi=300)
        plt.close()

# ---------- Save summary table as CSV ----------
out = open('../data/s5_summary.csv', 'w')
out.write('Exp,Parameter,Value,Vth_lin (V),SS (mV/dec),Ioff (A),Id(1.1,0.4) (mA),Id(1.1,1.1) (mA)\n')
for r in summary:
    out.write(','.join(str(x) for x in r) + '\n')
out.close()

print('\nSummary saved to ../data/s5_summary.csv')
for r in summary:
    print(r)
