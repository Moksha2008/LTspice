import numpy as np
import matplotlib.pyplot as plt

# ================= SETTINGS =================
spice_file = '../data/s6_search4.txt'
top_n = 5
# ============================================

# ---------- TCAD data (first row is a header) ----------
tg = np.genfromtxt('../data/idvg_real.csv', delimiter=',', skip_header=1)
td = np.genfromtxt('../data/idvd_real.csv', delimiter=',', skip_header=1)
tg = tg[np.argsort(tg[:, 0])]
td = td[np.argsort(td[:, 0])]
vg_t = tg[:, 0]
id_g_t = tg[:, 1]
vd_t = td[:, 0]
id_d_t = td[:, 1]

# ---------- Read SPICE export ----------
raw = open(spice_file, 'rb').read()
if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
    text = raw.decode('utf-16')
else:
    text = raw.decode('latin-1')

labels = []      # parameter text of each run
data = []        # data of each run
for line in text.splitlines():
    line = line.strip()
    if line.startswith('Step Information'):
        labels.append(line.split(':', 1)[1].split('(')[0].strip())
        data.append([])
        continue
    try:
        vs, i1, i2 = line.split()
        data[-1].append([float(vs), float(i1), float(i2)])
    except (ValueError, IndexError):
        pass

print('runs read:', len(data))

# ---------- Score every run: RMS error as % of TCAD max ----------
rows = []        # each row: [total, err_idvg, err_idvd, run number]
for r in range(len(data)):
    d = np.array(data[r])
    v = d[:, 0]
    i1 = d[:, 1]
    i2 = d[:, 2]
    e_g = 100 * np.sqrt(np.mean((np.interp(vg_t, v, i1) - id_g_t) ** 2)) / id_g_t.max()
    e_d = 100 * np.sqrt(np.mean((np.interp(vd_t, v, i2) - id_d_t) ** 2)) / id_d_t.max()
    rows.append([e_g + e_d, e_g, e_d, r])

rows.sort()      # lowest total error first

# save all scores
out = open('../data/s6_scores.csv', 'w')
out.write('score,err_IDVG_%,err_IDVD_%,params\n')
for row in rows:
    out.write(str(row[0]) + ',' + str(row[1]) + ',' + str(row[2]) + ',"' + labels[row[3]] + '"\n')
out.close()

print('\nBest', top_n, '(lower is better):')
for row in rows[:top_n]:
    print('  total', round(row[0], 1), ' (ID-VG', round(row[1], 1), '%, ID-VD', round(row[2], 1), '%) ', labels[row[3]])

# ---------- Plot the best run ----------
best = rows[0][3]
d = np.array(data[best])

fig, ax = plt.subplots(1, 2, figsize=(12, 4.8))
ax[0].plot(vg_t, id_g_t * 1e6, 'ko', markevery=3, markersize=4, label='TCAD')
ax[0].plot(d[:, 0], d[:, 1] * 1e6, label='SPICE (best)')
ax[1].plot(vd_t, id_d_t * 1e6, 'ko', markevery=3, markersize=4, label='TCAD')
m = d[:, 0] <= 1.5
ax[1].plot(d[m, 0], d[m, 2] * 1e6, label='SPICE (best)')

ax[0].set_title('ID-VGS at VDS = 0.4 V')
ax[1].set_title('ID-VDS at VGS = 0.9 V')
ax[0].set_xlabel('VGS (V)')
ax[1].set_xlabel('VDS (V)')
for a in ax:
    a.set_ylabel('ID (uA/um)')
    a.grid(True)
    a.legend()
fig.suptitle(labels[best], fontsize=9)

plt.tight_layout()
plt.savefig('../figures/s6_search_best.png', dpi=300)
plt.show()
